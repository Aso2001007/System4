<?php require 'commom_item.php'?>
<link rel="stylesheet" href="./css/item.css">
<?php
if (isset($_GET['color_id'])){
    switch ($_GET['color_id']){
        case 1:$color_id=1;break;
        case 2:$color_id=2;break;
        case 3:$color_id=3;break;
        case 4:$color_id=4;break;
        case 5:$color_id=5;break;
        case 6:$color_id=6;break;
        case 7:$color_id=7;break;
    }
}else{
    $color_id=1;
}


echo '<p class="subhead">商品詳細</p>';
$pdo =new PDO(//DB接続
    'mysql:dbname=LAA1290633-system4; host=mysql152.phy.lolipop.lan',
    'LAA1290633','daisuke0804');
$item_id = ($_GET['id']);
$stmt = $pdo->prepare('select * from item where item_id = :item_id');
$stmt ->bindParam(':item_id', $item_id,PDO::PARAM_INT);
$rt = $stmt->execute();
echo "rt = dummy $rt start";
print_r($stmt->errorInfo());
echo "rt = dummy $rt end" ;
echo "rt = $rt";
echo "item_id ($item_id)";

echo '<form action="cart-insert.php" method="post">';//カートに入れる
$cnt=0;
foreach ( $stmt as $row ) {

    ++$cnt;
    echo "cnt =b ($cnt)";
    echo '<div id="picture"><img src = "./img/',$item_id,'_',$color_id,'.png"></div>';
    echo '<div id="item_back"></div>';
    echo '<p id="item_name">',$row['item_name'],'</p>';
    echo '<p id="price">','¥',$row['price'],'</p>';

    echo '<div class="explanatory"></div>';//商品説明
    echo '<p id="exp-text">--商品説明文--</p>';
    echo '<p id="exp">',$row['text'], '</p>';

    $sql = $pdo->prepare('select * from color where item_id = :item_id order by item_id asc');
    $sql ->bindParam(':item_id', $item_id,PDO::PARAM_INT);
    $sql->execute();
    if(isset($sql)){
        echo '<select id ="color" onChange=location.href="./item.php?item_id=',$item_id,'&color_id=',$color_id,'">';
    }
    foreach ($sql as $color_data){
        $color_id=$color_data['color_id'];
        echo '<option value="' . $color_id . ' name="',$color_id,'"> ' . $color_data['color_name'] . '</option>';
    }
    if(isset($sql)){
        echo '</select>';
    }


//    echo '<form action="item.php" method="get">';
//    if(isset($sql)){
//        echo '<select id ="color" >';
//    }
//    foreach ($sql as $color_data){
//        $color_id=$color_data['color_id'];
//        echo '<a href="item.php?id=',$item_id,'&color_id=',$color_id,'"><option value="' . $color_id . '">' . $color_data['color_name'] . '</option></a>';
//    }
//    if(isset($sql)){
//        echo '</select>';
//    }
//    echo'</form>';

    echo '<div class="back"></div>';

    echo '<p id ="num-t">数量：</p>';//ドロップダウン数量
    echo '<select id="number" name="number">';
    for ($i = 1; $i < 11; $i++) {
        echo '<option value="' . $i . '">' . $i . '</option>';
    }
    echo '</select>';

    echo '<button type="submit" id="cart-in">カートに入れる</button>';

}
echo '</form>';
$pdo=null;
?>
