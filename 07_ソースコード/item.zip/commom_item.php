<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title></title>
    <link rel="stylesheet" href="./css/sample.css">
</head>
<body>

<div class="head">
    <a href="toppage.php" id="vanner">文房具サイト</a>
    <button type="submit"  onclick=location.href="./login-in.php" id="cart">カートの中　　🛒</button><br>
    <button type="submit" id="infor-regster" onclick=location.href="./register.php">会員登録</button>
    <button type="submit" id="log" onclick=location.href="./login-in.php">ログイン</button>
    <form action="list.php" method="get">
        <input type="search" id="keyword" name="keyword" placeholder="キーワードで検索">
        <button type="submit" id="keyword-button">🔍</button>
</div>
<dl class="category">
    <dt id="all"><a href="list.php?default=1">全ての商品</a></dt>
    <dt><hr width="210"></dt>
    <dt id="cp"><a href="list.php?sql=10">キャンペーン</a></dt>
    <dt><hr width="210"></dt>
    <dt id="sortname">並び替え</dt>
    <dt><hr width="210"></dt>
    <dt class="sort"><a href="list.php?sql=6">価格が安い順</a></dt>
    <dt><hr width="210"></dt>
    <dt class="sort"><a href="list.php?sql=7">価格が高い順</a></dt>
    <dt><hr width="210"></dt>
    <dt class="sort"><a href="list.php?sql=8">新着順</a></dt>
    <dt><hr width="210"></dt>
    <dt id="sortname">カテゴリーで探す</dt>
    <dt><hr width="210"></dt>
    <dt class="sort"><a href="list.php?sql=1">鉛筆、ペン</a></dt>
    <dt><hr width="210"></dt>
    <dt class="sort"><a href="list.php?sql=2">消しゴム</a></dt>
    <dt><hr width="210"></dt>
    <dt class="sort"><a href="list.php?sql=3">定規</a></dt>
    <dt><hr width="210"></dt>
    <dt class="sort"><a href="list.php?sql=4">筆箱</a></dt>
    <dt><hr width="210"></dt>
    <dt class="sort"><a href="list.php?sql=5">雑貨</a></dt>
    <dt><hr width="210"></dt>
</dl>
</form>

<script src="./script/script.js"></script>
</body>
</html>